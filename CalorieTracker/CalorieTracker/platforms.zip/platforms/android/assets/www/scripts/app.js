﻿function search() { // This method is called as the entry point. It will fire when the user clicks search
    // Get the search input control as an object
    const searchQry = document.getElementById('searchQuery').value;
    document.getElementById('searchQuery').value = '';
    // self calling function to load the circle under the search input
    (function () { showLoading() })();
    // through some logging into the mix
    console.log('Show loading image request');
    console.log('Term to search for ' + searchQry);
    // If the user has inputted a search term make the AJAX call to get the data
    if (searchQry != null) {
        (function () {
            console.log('Passed search term to xhr call: ' + searchQry);
            getData(searchQry);
        })();
        return;
    }
    else {
        return;
    }
}
// This function is used to display the data for the user
function parseData(data) {
    let results = document.getElementById('searchResults');

    let foodCount = data.count;
    let foodString = '';
    let tempStr = '';

    console.log('Start parseData method');
    if (data == null) {
        console.log('Data is returned by the api call is null')
        return;
    }
    else {
        console.log('Received data from server');


        // Build the html to display the results
        // Build the results into an unordered list to get the code going. Refine as needed later
        foodString += '<ol type="1">';
            for (x = 0; x < foodCount; x++)
            {
                tempStr = data.foods[x].food.desc.name;
                if (tempStr.indexOf('UPC') > 0) {
                    foodString += '<li><b>Name</b>: ' + tempStr.substring(0, tempStr.indexOf('UPC') - 2) + '</li>';
                } else {
                    foodString += '<li><b>Name</b>: ' + tempStr + '</li>';
                }
                
                    foodString += '<ol type="a">';
                    // Got the names of the food, lets get the, ingredients, serving size, calories and protien
                    try {
                        tempStr = data.foods[x].food.ing.desc;
                        foodString += '<li>' + tempStr + '</li>';
                    } catch(err) {
                        console.log(err.message);
                    }
                        
                        for (y = 0; y < data.foods[x].food.nutrients.length; y++)
                        {
                            // Calories
                            if (data.foods[x].food.nutrients[y].nutrient_id == 208) {
                                tempStr = data.foods[x].food.nutrients[y].value + data.foods[x].food.nutrients[y].unit;
                                foodString += '<li><b>Calories</b>: ' + tempStr + '</li>';
                            }
                            // Protein
                            else if (data.foods[x].food.nutrients[y].nutrient_id == 203) {
                                tempStr = data.foods[x].food.nutrients[y].value + data.foods[x].food.nutrients[y].unit; 
                                foodString += '<li><b>Protein</b>: ' + tempStr + '</li>';
                            }
                        }

                    foodString += '</ol>';
            }
        foodString += '</ol>';

    }
    // Display the results in the results area
    document.getElementById('searchResults').innerHTML = foodString;
}
// The is the method that displays the loading circle. Called from the self call function above
function showLoading() {
    let loadingImg = '<img src="/images/giphy.gif" width="90"/>';
    let results = document.getElementById('searchResults');
    results.innerHTML = loadingImg;
    console.log('Image loaded');
}
// This is the method that makes the AJAX call
function getData(searchQry) {
    console.log('Start XHR call using search term: ' + searchQry);
    // declare the XMLHttpRequest
    var xhttp = new XMLHttpRequest();
    // Establish what to do with data from the server as it is received
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            console.log('received good data; status: ' + this.status + '. Ready state: ' + this.readyState);
            // Log the JSON data received from the server
            console.log('JSON received: ' + this.responseText);
            // Pass the JSON object to the parseData method above
            parseData(JSON.parse(this.responseText));
            return;
        }
        else if (this.readyState == 1) {
            console.log('Connection established');
        }
        else if (this.readyState == 2) {
            console.log('Request Received');
        }
        else if (this.readyState == 3 && this.status == 200) {
            console.log('Request is being processed');
        }
        else if (this.status == 500) {
            document.getElementById('searchResults').innerHTML = 'Internal Server error. Please contact the administrator through the app store';
        }
        else if (this.status == 404) {
            document.getElementById('searchResults').innerHTML = 'Requested site not found. Please notify the administartor through the app store';
        }
        else {
            // This will just log the server responses until we get a success or will show other errors.
            // First time run will show an error but it is just building the request. Ignore first error
            console.log('error receiving data; status: ' + this.status + '. Ready state: ' + this.readyState);
        }
    };
    console.log('start call to server');
    // Open the request line to the server. Using the Web Api that interfaces with the USDA food database.
    xhttp.open("GET", "http://calorietrackerwebapi.azurewebsites.net/api/values/" + searchQry, true);
    // Enusre we get JSON back from the server
    xhttp.setRequestHeader("Content-type", "application/json");
    // Send the request. It follows up inside the if statement above... under xhttp.onreadystatechange = function() { ..... }
    xhttp.send();
    console.log('Logged call to server complete');
}